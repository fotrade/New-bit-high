<?php 

$host = 'trustfxaid.com';  // the domain name .com without https://

$username = 'support@trustfxaid.com'; //username of the email account

$password = 'Oja9-f((cG7!'; //password of the email account

$setForm = 'support@trustfxaid.com'; //email that is mail is sending from (same as the username);


?>